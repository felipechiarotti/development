#include <stdio.h>
#include <pthread.h>

void *faz_algo(void *argumento){
    AEHIAEHEAIHEA
    AEIHEAOHEOHJAO
    AHEAKJAEKEJAL
}


int main(int argc, char *argv){
    pthread_t thread;
    pthread_create(&thread, NULL, faz_algo, NULL);
}